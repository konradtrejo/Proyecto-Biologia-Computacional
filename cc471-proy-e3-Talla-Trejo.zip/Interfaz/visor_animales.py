# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'visor_animales.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_visor_animales(object):
    def setupUi(self, visor_animales):
        visor_animales.setObjectName("visor_animales")
        visor_animales.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(visor_animales)
        self.centralwidget.setObjectName("centralwidget")
        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(410, 340, 291, 201))
        self.textEdit.setObjectName("textEdit")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(90, 100, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(90, 130, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(90, 160, 75, 23))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(90, 190, 75, 23))
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_5.setGeometry(QtCore.QRect(30, 270, 75, 23))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_6.setGeometry(QtCore.QRect(40, 280, 75, 23))
        self.pushButton_6.setObjectName("pushButton_6")
        self.pushButton_7 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_7.setGeometry(QtCore.QRect(50, 290, 75, 23))
        self.pushButton_7.setObjectName("pushButton_7")
        self.pushButton_8 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_8.setGeometry(QtCore.QRect(60, 300, 75, 23))
        self.pushButton_8.setObjectName("pushButton_8")
        self.pushButton_9 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_9.setGeometry(QtCore.QRect(70, 310, 75, 23))
        self.pushButton_9.setObjectName("pushButton_9")
        self.pushButton_10 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_10.setGeometry(QtCore.QRect(80, 320, 75, 23))
        self.pushButton_10.setObjectName("pushButton_10")
        self.pushButton_11 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_11.setGeometry(QtCore.QRect(90, 330, 75, 23))
        self.pushButton_11.setObjectName("pushButton_11")
        self.pushButton_12 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_12.setGeometry(QtCore.QRect(100, 340, 75, 23))
        self.pushButton_12.setObjectName("pushButton_12")
        self.pushButton_13 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_13.setGeometry(QtCore.QRect(110, 350, 75, 23))
        self.pushButton_13.setObjectName("pushButton_13")
        self.pushButton_14 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_14.setGeometry(QtCore.QRect(120, 360, 75, 23))
        self.pushButton_14.setObjectName("pushButton_14")
        self.pushButton_15 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_15.setGeometry(QtCore.QRect(130, 370, 75, 23))
        self.pushButton_15.setObjectName("pushButton_15")
        self.pushButton_16 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_16.setGeometry(QtCore.QRect(140, 380, 75, 23))
        self.pushButton_16.setObjectName("pushButton_16")
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser.setGeometry(QtCore.QRect(375, 11, 341, 301))
        self.textBrowser.setObjectName("textBrowser")
        visor_animales.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(visor_animales)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        visor_animales.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(visor_animales)
        self.statusbar.setObjectName("statusbar")
        visor_animales.setStatusBar(self.statusbar)

        self.retranslateUi(visor_animales)
        QtCore.QMetaObject.connectSlotsByName(visor_animales)

    def retranslateUi(self, visor_animales):
        _translate = QtCore.QCoreApplication.translate
        visor_animales.setWindowTitle(_translate("visor_animales", "MainWindow"))
        self.textEdit.setHtml(_translate("visor_animales", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">AAAAAAA</p></body></html>"))
        self.pushButton.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_2.setText(_translate("visor_animales", "Llama"))
        self.pushButton_3.setText(_translate("visor_animales", "Vicuña"))
        self.pushButton_4.setText(_translate("visor_animales", "Guanaco"))
        self.pushButton_5.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_6.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_7.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_8.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_9.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_10.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_11.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_12.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_13.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_14.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_15.setText(_translate("visor_animales", "Alpaca"))
        self.pushButton_16.setText(_translate("visor_animales", "Alpaca"))
        self.textBrowser.setHtml(_translate("visor_animales", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/prefijoNuevo/Alpaca.jpg\" /></p></body></html>"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    visor_animales = QtWidgets.QMainWindow()
    ui = Ui_visor_animales()
    ui.setupUi(visor_animales)
    visor_animales.show()
    sys.exit(app.exec_())

